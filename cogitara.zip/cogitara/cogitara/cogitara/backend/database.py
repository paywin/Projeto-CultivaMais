from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, ForeignKey, Float
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(256), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    interactions = relationship("InteractionHistory", back_populates="user")
    scenarios = relationship("ScenarioSimulation", back_populates="user")

class Client(Base):
    __tablename__ = "clients"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    email = Column(String(100))
    phone = Column(String(30))
    created_at = Column(DateTime, default=datetime.utcnow)

    feedbacks = relationship("Feedback", back_populates="client")
    predictions = relationship("Prediction", back_populates="client")

class InteractionHistory(Base):
    __tablename__ = "interaction_history"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    prompt = Column(Text, nullable=False)
    response = Column(Text, nullable=False)

    user = relationship("User", back_populates="interactions")
    client = relationship("Client")

class ScenarioSimulation(Base):
    __tablename__ = "scenario_simulations"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String(150))
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    result = Column(Text)

    user = relationship("User", back_populates="scenarios")

class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"))
    type = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    data = Column(Text)

    client = relationship("Client", back_populates="predictions")

class Feedback(Base):
    __tablename__ = "feedbacks"
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"))
    score = Column(Float)
    comment = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    client = relationship("Client", back_populates="feedbacks")

DATABASE_URL = "mysql+pymysql://root:senha@localhost:3306/cogitara"

engine = create_engine(DATABASE_URL, echo=True, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_db():
    Base.metadata.create_all(bind=engine)
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, ForeignKey, Float
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(256), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    interactions = relationship("InteractionHistory", back_populates="user")
    scenarios = relationship("ScenarioSimulation", back_populates="user")

class Client(Base):
    __tablename__ = "clients"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    email = Column(String(100))
    phone = Column(String(30))
    created_at = Column(DateTime, default=datetime.utcnow)

    feedbacks = relationship("Feedback", back_populates="client")
    predictions = relationship("Prediction", back_populates="client")

class InteractionHistory(Base):
    __tablename__ = "interaction_history"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    prompt = Column(Text, nullable=False)
    response = Column(Text, nullable=False)

    user = relationship("User", back_populates="interactions")
    client = relationship("Client")

class ScenarioSimulation(Base):
    __tablename__ = "scenario_simulations"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String(150))
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    result = Column(Text)

    user = relationship("User", back_populates="scenarios")

class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"))
    type = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    data = Column(Text)

    client = relationship("Client", back_populates="predictions")

class Feedback(Base):
    __tablename__ = "feedbacks"
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"))
    score = Column(Float)
    comment = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    client = relationship("Client", back_populates="feedbacks")

DATABASE_URL = "mysql+pymysql://root:senha@localhost:3306/cogitara"

engine = create_engine(DATABASE_URL, echo=True, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_db():
    Base.metadata.create_all(bind=engine)
