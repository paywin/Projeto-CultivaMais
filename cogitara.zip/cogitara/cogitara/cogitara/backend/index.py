from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import httpx

app = FastAPI()

# Permitir requisições do front
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Sua chave da Groq API
GROQ_API_KEY = "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"

# Endpoint de status
@app.get("/status")
async def status():
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(
                "https://api.groq.com/openai/v1/models",
                headers={"Authorization": f"Bearer {GROQ_API_KEY}"}
            )
            return {
                "status": "online",
                "services": {
                    "internet": True,
                    "groq_api": r.status_code == 200
                }
            }
    except:
        return {"status": "offline", "services": {"internet": False, "groq_api": False}}

# Endpoint de chat
@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    prompt = data.get("prompt", "")

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {GROQ_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "llama3-8b-8192",
                "messages": [{"role": "user", "content": prompt}]
            }
        )

        result = resp.json()  # <<< corrigido: não usar await
        # Extrai a resposta do bot
        content = result["choices"][0]["message"]["content"]
        return {"reply": content}