import React, { useState, useRef, useEffect } from 'react';
import './styles.css';

const API_BASE_URL = 'http://localhost:8000';

export default function App() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [connectionError, setConnectionError] = useState(null);
  const messagesEndRef = useRef(null);

  // Test backend status on component mount
  useEffect(() => {
    async function testBackendStatus() {
      try {
        const res = await fetch(`${API_BASE_URL}/status`);
        const data = await res.json();
        console.log('Backend status:', data);
      } catch (err) {
        setConnectionError('Backend não está acessível');
      }
    }
    testBackendStatus();
  }, []);

  // Auto-scroll to latest message
  useEffect(() => {
    const timer = setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
    return () => clearTimeout(timer);
  }, [messages]);

  // Process SSE stream from backend
  const processStream = async (reader, botMessage) => {
    const decoder = new TextDecoder('utf-8');
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        // Process each line
        const lines = buffer.split('\n');
        buffer = ''; // Reset buffer to rebuild with unprocessed lines

        for (const line of lines) {
          if (line.trim() === '') continue;
          if (line === '[DONE]') return;

          // Extract data (may have multiple 'data: ' prefixes)
          const data = line.replace(/^(\s*data:\s*)+/, '').trim();
          
          if (!data) continue;

          try {
            const parsed = JSON.parse(data);
            const newContent = parsed.choices?.[0]?.delta?.content || '';
            if (newContent) {
              botMessage.content += newContent;
              setMessages(prev =>
                prev.map((msg, idx) =>
                  idx === prev.length - 1 ? { ...botMessage } : msg
                )
              );
            }
          } catch (e) {
            // Fallback for non-JSON data
            if (data && data !== '[DONE]') {
              botMessage.content += data;
              setMessages(prev =>
                prev.map((msg, idx) =>
                  idx === prev.length - 1 ? { ...botMessage } : msg
                )
              );
            }
          }
        }
      }
    } finally {
      // Add any remaining content
      if (buffer.trim() && buffer.trim() !== '[DONE]') {
        botMessage.content += buffer;
        setMessages(prev =>
          prev.map((msg, idx) =>
            idx === prev.length - 1 ? { ...botMessage } : msg
          )
        );
      }
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    setIsLoading(true);
    setConnectionError(null);

    const userMessage = { role: 'user', content: input };
    const botMessage = { role: 'bot', content: '', isError: false };

    setMessages(prev => [...prev, userMessage, botMessage]);
    setInput('');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);

    try {
      const response = await fetch(`${API_BASE_URL}/chat/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream'
        },
        body: JSON.stringify({ prompt: input }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok || !response.body) {
        throw new Error('Erro na conexão com o backend');
      }

      await processStream(response.body.getReader(), botMessage);

    } catch (error) {
      let message = '▲ Erro inesperado.\n\n• Tente novamente mais tarde';
      if (error.message === 'Failed to fetch') {
        message = '▲ Servidor Indisponível\n\n• Verifique se o backend está rodando\n• Confira sua internet';
        setConnectionError('Não foi possível conectar ao servidor');
      } else if (error.name === 'AbortError') {
        message = '▲ Tempo Esgotado\n\n• A resposta demorou demais\n• Tente uma pergunta mais simples';
      }

      setMessages(prev => [
        ...prev.slice(0, -1),
        { role: 'bot', content: message, isError: true }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="app-container">
      <header className="header">
        <h1>Cogitara</h1>
        {connectionError && (
          <div className="connection-error">
            ⚠️ {connectionError}
          </div>
        )}
      </header>

      <main className="chat-window">
        {messages.length === 0 && (
          <div className="empty-state">
            <p>Digite uma mensagem para começar a conversa</p>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`message ${msg.role} ${msg.isError ? 'error' : ''}`}>
            <div className="message-content">
              {msg.role === 'bot' && <span className="bot-label">Cogitara:</span>}
              {msg.content.split('\n').map((line, idx) => (
                <React.Fragment key={idx}>{line}<br /></React.Fragment>
              ))}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="message bot">
            <div className="typing-indicator">
              <span></span><span></span><span></span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </main>

      <form onSubmit={handleSubmit} className="input-area">
        <div className="input-wrapper">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Digite sua mensagem..."
            disabled={isLoading}
            rows={3}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            aria-label="Enviar mensagem"
          >
            {isLoading ? (
              <span className="spinner"></span>
            ) : (
              <svg viewBox="0 0 24 24" width="20" height="20">
                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" fill="currentColor" />
              </svg>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}