// indexIA.js

export function entenderIntencao(text) {
  text = text.toLowerCase();
  if (text.includes('olá') || text.includes('oi')) return 'saudacao';
  if (text.includes('obrigado') || text.includes('valeu')) return 'agradecimento';
  if (text.includes('ajuda') || text.includes('suporte')) return 'pedido_ajuda';
  if (text.includes('tchau') || text.includes('até')) return 'despedida';
  return 'nao_entendi';
}

export function responder(intencao) {
  switch (intencao) {
    case 'saudacao':
      return 'Olá! Eu sou a sua assistente virtual. Como posso ajudar?';
    case 'agradecimento':
      return 'De nada! Estou aqui para ajudar sempre que precisar.';
    case 'pedido_ajuda':
      return 'Claro, me diga com o que você precisa de ajuda.';
    case 'despedida':
      return 'Até logo! Foi bom falar com você.';
    default:
      return 'Desculpe, não entendi. Pode reformular?';
  }
}
