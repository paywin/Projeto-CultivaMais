const colors = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f2f2f2',
    fontFamily: 'Arial',
  },
  chatBox: {
    flex: 1,
    overflowY: 'auto',
    padding: '20px',
  },
  botMsg: {
    backgroundColor: '#d9edf7',
    padding: '10px',
    borderRadius: '10px',
    margin: '5px 0',
    maxWidth: '70%',
    alignSelf: 'flex-start'
  },
  userMsg: {
    backgroundColor: '#dff0d8',
    padding: '10px',
    borderRadius: '10px',
    margin: '5px 0',
    maxWidth: '70%',
    alignSelf: 'flex-end'
  },
  inputArea: {
    display: 'flex',
    padding: '10px',
    backgroundColor: '#fff',
  },
  input: {
    flex: 1,
    padding: '10px',
    fontSize: '16px',
    marginRight: '10px'
  },
  button: {
    padding: '10px 20px',
    backgroundColor: '#337ab7',
    color: '#fff',
    border: 'none',
    borderRadius: '5px'
  }
};

export default colors;
